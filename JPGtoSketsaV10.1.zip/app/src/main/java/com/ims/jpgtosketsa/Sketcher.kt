package com.ims.jpgtosketsa

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.*

class SketchParams(
    val mode: Int,    // 0 pensil hitam-putih, 1 kartun berwarna, 2 kartun hitam-putih
    val blur: Int,    // 0..100 ketebalan/kehalusan garis
    val dark: Int,    // 0..100 kegelapan / kekuatan garis
    val color: Int,   // 0..100 kekuatan warna (mode 1)
    val grain: Int,   // 0..100 tekstur kertas
    val paper: Int    // 0 putih, 1 krem, 2 papan tulis, 3 transparan (PNG, hanya garis)
)

object Sketcher {
    fun render(src: Bitmap, p: SketchParams): Bitmap {
        val w = src.width
        val h = src.height
        val n = w * h
        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val scale = max(w, h) / 900f
        val gray = IntArray(n) {
            val c = px[it]
            (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
        }
        val v = IntArray(n)

        val fill = IntArray(n)
        if (p.mode == 1 || p.mode == 2) {
            cartoon(px, gray, w, h, scale, p, v, fill)
        } else {
            // Color dodge: gambar / (kebalikan gambar yang di-blur)
            val inv = IntArray(n) { 255 - gray[it] }
            boxBlur(inv, w, h, max(1, ((2f + p.blur * 0.38f) * scale).roundToInt()))
            val gamma = 0.6 + p.dark / 100.0 * 1.4
            val lut = IntArray(256) { (255.0 * (it / 255.0).pow(gamma)).roundToInt().coerceIn(0, 255) }
            for (i in 0 until n) {
                val d = 256 - inv[i]
                v[i] = lut[min(255, gray[i] * 256 / max(1, d))]
            }
        }

        val out = IntArray(n)
        val colored = p.mode == 1 || p.mode == 2
        val flat = p.mode == 2
        val kc = p.color / 100f
        val gr = p.grain / 100f
        val pr: Float
        val pg: Float
        val pb: Float
        when (p.paper) {
            1 -> { pr = 245f; pg = 236f; pb = 215f }
            else -> { pr = 255f; pg = 255f; pb = 255f }
        }
        for (i in 0 until n) {
            val noise = ((i * -1640531535) ushr 24) / 255f
            val vv = v[i] * (1f - gr * 0.25f * noise)
            var lr = 255f
            var lg = 255f
            var lb = 255f
            if (colored) {
                val c = fill[i]
                val k = if (flat) 1f else kc
                lr = 255f * (1f - k) + Color.red(c) * k
                lg = 255f * (1f - k) + Color.green(c) * k
                lb = 255f * (1f - k) + Color.blue(c) * k
            }
            if (p.paper == 3) {
                val al = (255f - vv).toInt().coerceIn(0, 255)
                out[i] = if (p.mode == 1) Color.argb(al, (lr * 0.5f).toInt().coerceIn(0, 255), (lg * 0.5f).toInt().coerceIn(0, 255), (lb * 0.5f).toInt().coerceIn(0, 255))
                else Color.argb(al, 20, 20, 24)
                continue
            }
            val r: Float
            val g: Float
            val b: Float
            if (p.paper == 2) {
                if (flat) { lr = 255f; lg = 255f; lb = 255f }
                val t = (255f - vv) / 255f
                r = 43f + (lr - 43f) * t
                g = 58f + (lg - 58f) * t
                b = 51f + (lb - 51f) * t
            } else {
                r = vv * lr / 255f * pr / 255f
                g = vv * lg / 255f * pg / 255f
                b = vv * lb / 255f * pb / 255f
            }
            out[i] = Color.rgb(r.toInt().coerceIn(0, 255), g.toInt().coerceIn(0, 255), b.toInt().coerceIn(0, 255))
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }


    /**
     * Efek kartun.
     * Mode 1: warna diratakan jadi blok-blok datar + garis luar hitam tebal.
     * Mode 2: sama, tapi hanya nada abu-abu datar (4 tingkat) + garis luar hitam tebal.
     * v = faktor garis (255 putih, 0 garis hitam); fill = warna blok datar.
     */
    private fun cartoon(px: IntArray, gray: IntArray, w: Int, h: Int, scale: Float, p: SketchParams, v: IntArray, fill: IntArray) {
        val n = w * h
        // 1) Haluskan warna supaya tekstur/noise hilang
        val sr = max(1, (1.5f * scale).roundToInt())
        val r = IntArray(n) { Color.red(px[it]) }
        val g = IntArray(n) { Color.green(px[it]) }
        val b = IntArray(n) { Color.blue(px[it]) }
        boxBlur(r, w, h, sr); boxBlur(g, w, h, sr); boxBlur(b, w, h, sr)

        // 2) Ratakan jadi blok warna / nada
        if (p.mode == 1) {
            val levels = 6
            for (i in 0 until n) {
                val mx = max(r[i], max(g[i], b[i])).coerceAtLeast(1)
                val idx = ((mx / 255f) * (levels - 1)).roundToInt()
                val vq = 45f + idx * (255f - 45f) / (levels - 1)
                val f = (vq / mx).coerceAtMost(4f)
                // naikkan kejenuhan supaya warnanya "ngejreng" ala kartun
                val sat = 1.3f
                val rr = (mx - (mx - r[i]) * sat) * f
                val gg = (mx - (mx - g[i]) * sat) * f
                val bb = (mx - (mx - b[i]) * sat) * f
                fill[i] = Color.rgb(rr.toInt().coerceIn(0, 255), gg.toInt().coerceIn(0, 255), bb.toInt().coerceIn(0, 255))
            }
        } else {
            val bias = (p.dark - 70) / 100f * 0.15f
            for (i in 0 until n) {
                val l = ((r[i] * 299 + g[i] * 587 + b[i] * 114) / 1000f) / 255f - bias
                val t = when {
                    l > 0.78f -> 255
                    l > 0.55f -> 205
                    l > 0.32f -> 150
                    else -> 85
                }
                fill[i] = Color.rgb(t, t, t)
            }
        }

        // 3) Garis luar: Sobel dari gambar yang sudah dihaluskan
        val gl = IntArray(n) { (r[it] * 299 + g[it] * 587 + b[it] * 114) / 1000 }
        boxBlur(gl, w, h, max(1, ((0.5f + p.blur * 0.02f) * scale).roundToInt()))
        val thr = 120f - p.dark * 0.95f      // makin gelap, makin banyak garis
        val lm = IntArray(n)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = -gl[i - w - 1] - 2 * gl[i - 1] - gl[i + w - 1] + gl[i - w + 1] + 2 * gl[i + 1] + gl[i + w + 1]
            val gy = -gl[i - w - 1] - 2 * gl[i - w] - gl[i - w + 1] + gl[i + w - 1] + 2 * gl[i + w] + gl[i + w + 1]
            val m = abs(gx) + abs(gy)
            lm[i] = (((m - thr) / (thr * 0.6f + 1f)).coerceIn(0f, 1f) * 255f).toInt()
        }
        // 4) Tebalkan garis: blur lalu potong di ambang rendah
        boxBlur(lm, w, h, max(1, (0.6f * scale * (1f + p.blur * 0.04f)).roundToInt()))
        for (i in 0 until n) {
            val l = ((lm[i] - 30) * 255 / 50).coerceIn(0, 255)
            v[i] = 255 - l
        }
    }

    /** Blur kotak 3x (mendekati Gaussian), tepi di-clamp. */
    private fun boxBlur(a: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(max(w, h))
        val k = 2 * r + 1
        repeat(3) {
            for (y in 0 until h) {
                val o = y * w
                var sum = 0
                for (i in -r..r) sum += a[o + i.coerceIn(0, w - 1)]
                for (x in 0 until w) {
                    tmp[x] = sum / k
                    sum += a[o + min(x + r + 1, w - 1)] - a[o + max(x - r, 0)]
                }
                System.arraycopy(tmp, 0, a, o, w)
            }
            for (x in 0 until w) {
                var sum = 0
                for (i in -r..r) sum += a[i.coerceIn(0, h - 1) * w + x]
                for (y in 0 until h) {
                    tmp[y] = sum / k
                    sum += a[min(y + r + 1, h - 1) * w + x] - a[max(y - r, 0) * w + x]
                }
                for (y in 0 until h) a[y * w + x] = tmp[y]
            }
        }
    }
}
